import './assets/main.css'

import { createApp } from 'vue'

import 'element-plus/dist/index.css'
import App from './App.vue'
import router, { setupRouter } from './router'
import VXETable from 'vxe-table'
import 'vxe-table/lib/style.css'
const app = createApp(App)
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import VXETablePluginElement from 'vxe-table-plugin-element'
import 'vxe-table-plugin-element/dist/style.css'
app.use(ElementPlus).use(VXETable)
VXETable.use(VXETablePluginElement)
setupRouter(app)
app.mount('#app')


<script lang="ts">
import { h, onMounted, ref, resolveComponent, type ComponentOptions } from 'vue';
export default {
    name: 'ElementView',
    setup(props: any, ctx: any) {
        const { attrs } = ctx;
        //大概80mb
        const a = new Array(20000000).fill(1)
        const options = [
            {
                value: 'Option1',
                label: 'Option1',
            },
            {
                value: 'Option2',
                label: 'Option2',
            },
            {
                value: 'Option3',
                label: 'Option3',
            },
            {
                value: 'Option4',
                label: 'Option4',
            },
            {
                value: 'Option5',
                label: 'Option5',
            },
        ]
        return () => h(resolveComponent('el-select') as ComponentOptions, {
            ...attrs,
            ...props,
        }, {
            default: () => {
                return () => options.map((item: any, key: any) => {
                    {
                        return h(resolveComponent('el-option-group') as ComponentOptions, {
                            label: item.label,
                            key: key
                        })
                    }
                })

            }
        })


    }
}
</script>
<!-- <script lang="ts" setup>

import { ElMessageBox } from 'element-plus';
import { h, onMounted, ref, resolveComponent, type ComponentOptions } from 'vue';
import { useRoute } from 'vue-router';

//大概80mb
const a = new Array(20000000).fill(1)
let myname = ref<any>('')
const route = useRoute()

const value = ref('')

const options = [
    {
        value: 'Option1',
        label: 'Option1',
    },
    {
        value: 'Option2',
        label: 'Option2',
    },
    {
        value: 'Option3',
        label: 'Option3',
    },
    {
        value: 'Option4',
        label: 'Option4',
    },
    {
        value: 'Option5',
        label: 'Option5',
    },
]

const dialogVisible = ref(false)

const handleClose = (done: () => void) => {
    ElMessageBox.confirm('Are you sure to close this dialog?')
        .then(() => {
            done()
        })
        .catch(() => {
            // catch error
        })
}

return

</script> -->


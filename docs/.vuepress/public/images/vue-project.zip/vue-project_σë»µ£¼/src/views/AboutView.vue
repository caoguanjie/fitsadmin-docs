<template>
  <div class="about">
    <h1>这是首页</h1>
  </div>
</template>

<style>

</style>

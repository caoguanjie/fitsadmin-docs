<template>
    <div>
        <vxe-grid ref="xGrid" v-bind="gridOptions" />
    </div>
</template>
<script lang="ts">
export default {
    name: 'TableView'
}
</script>
<script lang="ts" setup>
import { ref, reactive, onUnmounted } from 'vue'
import { type VxeGridInstance, VxeTableDefines, type VxeGridProps, type VxeGridPropTypes } from 'vxe-table'

interface RowVO {
    [key: string]: any
}

let xGrid = ref<VxeGridInstance<RowVO>>()

const footerData = ref<string[][]>([])

const gridOptions = reactive<VxeGridProps<RowVO>>({
    keepSource: false,
    border: true,
    showOverflow: true,
    showHeaderOverflow: true,
    showFooterOverflow: true,
    showFooter: true,
    height: 500,
    loading: false,
    rowConfig: {
        keyField: 'id'
    },
    checkboxConfig: {
        checkField: 'checked',
        labelField: 'id'
    },
    toolbarConfig: {

        tools: [
            { code: 'myPrint', name: '自定义打印' }
        ],
        import: true,
        export: true,
        print: true,
        zoom: true,
        custom: true
    },
    formConfig: {
        items: [
            { field: 'name', span: 3, title: '用户名', itemRender: { name: 'input', props: { placeholder: '请输入用户名' } } },
            { field: 'mobiTel', span: 3, title: '手机号码', itemRender: { name: 'input', props: { placeholder: '请输入手机号' } } },
            {
                field: 'status', span: 3, title: '用户状态', itemRender: {
                    name: 'ElSelect',
                    props: {
                        // multiple: true,
                        collapseTags: true,
                        collapseTagsTooltip: true,
                        clearable: true
                    },
                    options: [
                        {
                            value: '2',
                            label: '在职',
                        },
                        {
                            value: '3',
                            label: '离职',
                        },
                        {
                            value: '4',
                            label: '挂起',
                        },
                        {
                            value: '5',
                            label: '已关闭',
                        },
                    ]
                }
            },
            {
                field: 'tap', span: 3, title: '用户标签', itemRender: {
                    name: 'ElSelect',
                    props: {
                        // multiple: true,
                        collapseTags: true,
                        collapseTagsTooltip: true,
                        clearable: true
                    },
                    options: [
                        {
                            value: '2',
                            label: '项目私立',
                        }
                    ]
                }
            },
            {
                field: 'department', span: 3, title: '上级机构', itemRender: {
                    name: 'ElSelect',
                    props: {
                        // multiple: true,
                        collapseTags: true,
                        collapseTagsTooltip: true,
                        clearable: true
                    },
                    options: [
                        {
                            value: '2',
                            label: '检测机构',
                        },
                        {
                            value: '3',
                            label: '供应商',
                        },
                        {
                            value: '4',
                            label: '客户',
                        },
                        {
                            value: '5',
                            label: '运维商',
                        },
                    ]
                }
            },
        ]
    },
    footerMethod() {
        return footerData.value
    }
})

let colIndex = 0
let rowIndex = 1

const findColumnList = (size: number) => {
    return new Promise<VxeGridPropTypes.Columns>(resolve => {
        setTimeout(() => {
            const columns: VxeGridPropTypes.Columns = []
            for (let index = 0; index < size; index++) {
                const key = colIndex++
                const config: VxeTableDefines.ColumnOptions = {
                    field: key ? `col_${key}` : 'id',
                    title: key ? `标题_${key}` : 'ID',
                    width: 140,
                    type: null,
                    fixed: null
                }
                if (!key) {
                    config.type = 'checkbox'
                }
                if (key < 2) {
                    config.fixed = 'left'
                }
                columns.push(config)
            }
            resolve(columns)
        }, 250)
    })
}

const findDataList = (size: number) => {
    return new Promise<any[]>(resolve => {
        setTimeout(() => {
            const list: any[] = []
            for (let index = 0; index < size; index++) {
                const key = rowIndex++
                const item: any = { id: key, checked: false }
                // 由于生成数据比较耗时，所以固定生成1000字段
                Array.from(new Array(1000)).forEach((num, cIndex) => {
                    item[`col_${cIndex}`] = `内容_${cIndex}_${index}`
                })
                list.push(item)
            }
            resolve(list)
        }, 250)
    })
}

const init = async () => {
    let tableColumn: VxeGridPropTypes.Columns = []
    gridOptions.loading = true
    await Promise.all([
        findColumnList(200).then(columns => {
            let $grid = xGrid.value
            if ($grid) {
                tableColumn = columns
                $grid.loadColumn(columns)
                // $grid = null
            }
        }),
        findDataList(600).then(data => {
            let $grid = xGrid.value
            if ($grid) {
                $grid.loadData(data)
                // $grid = null
            }
        })
    ])

    let $grid = xGrid.value
    gridOptions.loading = false

    // 计算表尾数据 
    const footList: string[][] = [[]]
    tableColumn.forEach((column, index) => {
        footList[0].push(index === 0 ? '合计' : `${index}`)
    })
    footerData.value = footList
    if ($grid) {
        $grid.updateFooter()
        // $grid = null
    }
}

init()

onUnmounted(() => {
    console.log('页面销毁')
    // xGrid.value = null
})
</script>
  
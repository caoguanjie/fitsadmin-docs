<template>
    <div>
        <!-- <component :is="ElementView"></component> -->
        <ElementView></ElementView>

    </div>

</template>
<script lang="ts">
export default {
    name: 'TableView'
}
</script>
<script lang="ts" setup>
import ElementView from './ElementView.vue'
import { ElMessageBox } from 'element-plus';
import { onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
const value = ref('')
const drawer = ref(false)
const options = [
    {
        value: 'Option1',
        label: 'Option1',
    },
    {
        value: 'Option2',
        label: 'Option2',
    },
    {
        value: 'Option3',
        label: 'Option3',
    },
    {
        value: 'Option4',
        label: 'Option4',
    },
    {
        value: 'Option5',
        label: 'Option5',
    },
]
//大概80mb
// const a = new Array(20000000).fill(1)
let myname = ref<any>('')
const route = useRoute()
onMounted(() => {
    myname.value = route.query.name
})


const dialogVisible = ref(false)

const handleClose = (done: () => void) => {
    ElMessageBox.confirm('Are you sure to close this dialog?')
        .then(() => {
            done()
        })
        .catch(() => {
            // catch error
        })
}

</script>


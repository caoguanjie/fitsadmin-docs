import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import type { App } from 'vue';
import TableView from '@/views/TestView.vue'
const router: any = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => import('../views/AboutView.vue')
    },
    {
      path: '/home',
      name: 'home',
      component: () => import('../views/AboutView.vue')
    },
    {
      path: '/table',
      name: 'table',
      // route level code-splitting
      // this generates a separate chunk (About.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import('../views/TableView.vue')
    },
    {
      path: '/test',
      name: 'test',
      // route level code-splitting
      // this generates a separate chunk (About.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import('../views/TestView.vue')
    }
  ]
})
/**
 * 定义一个方法，方便main.ts直接调用。
 * @param app
 */
export function setupRouter(app: App) {
  app.use(router)
  router.$append = (index: any) => {
    router.addRoute(`TableView${index}`, {
      path: `/TableView${index}`,
      component: {
        ...TableView,
        name: `TableView${index}`
      },
    })
  }

  router.$push = (index: any) => {
    router.push({
      path: `/TableView${index}`,
      query: {
        name: `TableView${index}`
      }
    })
  }
}

export default router

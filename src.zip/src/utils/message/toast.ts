/* eslint-disable dot-notation */
import Vue from 'vue'
/**
 * 根据elementUI的通知$notify组件的api改造属于UI稿上面的消息提醒
 * 下面定制了成功、失败、警告三种提示框
 */

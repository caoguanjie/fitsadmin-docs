<template>
    <fits-icon-select modelValue="edit" />
</template>

<script lang="ts" setup>
import { FitsIconSelect } from '@/fits-components';
</script>
<style lang="scss" scoped>

</style>

<style lang="scss">

</style>

import empty from './index.vue'
import { withInstall } from '@/utils/base/withInstall'

const FitsEmpty = withInstall(empty)
export { FitsEmpty }
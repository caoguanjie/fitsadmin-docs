import InputSearch from './FitsInputSearch.vue'
import { withInstall } from '@/utils/base/withInstall'

const FitsInputSearch = withInstall(InputSearch)
export { FitsInputSearch }
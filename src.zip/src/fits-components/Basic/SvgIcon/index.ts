import Icon from './index.vue'
import { withInstall } from '@/utils/base/withInstall'

const SvgIcon = withInstall(Icon)
export { SvgIcon }
import * as FitsAdminUI from './all'
export * from './all'
export * from './type'
export default FitsAdminUI
import _FitsEditor from './FitsEditor.vue'
import { withInstall } from '@/utils/base/withInstall'

const FitsEditor = withInstall(_FitsEditor)
export { FitsEditor }